
public class GuGudan {

	public static void main(String[] args) {
		for(int dan=2; dan<10; dan++)
		{
			System.out.println("[" + dan + "]��");
			for(int num=1; num<10; num++)
			{
				System.out.print(dan + "*" + num + "=" + (dan*num) + " ");
			}
			System.out.println();
		}
	}

}
