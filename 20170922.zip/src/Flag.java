
public class Flag {

	public static void main(String[] args) {
		int odd = 0, even = 0;
		int flag = 0;
		for (int i = 1; i <= 10; i++) {
			if (flag == 0) {
				odd = odd + i;
				flag = 1;
			} else {
				even = even + i;
				flag = 0;
			}
		}
		System.out.println("Ȧ���� ��" + odd);
		System.out.println("¦���� ��" + even);

	}
}
