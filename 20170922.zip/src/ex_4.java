import java.util.Scanner;

//������ �Է¹޾Ƽ� �ϴ����α׷�
public class ex_4 {

	public static void main(String[] args) {
		int dan = 0; 
		Scanner scanner = new Scanner(System.in);
		System.out.print("1����9������ ������ ������ ���ڸ� �Է��ϼ���: ");
		dan = scanner.nextInt();
		switch(dan){
		case 1:
			for(int num=1; num<10; num++)
			{
				System.out.println(dan + "*" + num + "=" + (dan*num) + " ");
			}
			break;
		case 2:
			for(int num=1; num<10; num++)
			{
				System.out.println(dan + "*" + num + "=" + (dan*num) + " ");
			}
			break;
		case 3:
			for(int num=1; num<10; num++)
			{
				System.out.println(dan + "*" + num + "=" + (dan*num) + " ");
			}
			break;
		case 4:
			for(int num=1; num<10; num++)
			{
				System.out.println(dan + "*" + num + "=" + (dan*num) + " ");
			}
			break;
		case 5:
			for(int num=1; num<10; num++)
			{
				System.out.println(dan + "*" + num + "=" + (dan*num) + " ");
			}
			break;
		case 6:
			for(int num=1; num<10; num++)
			{
				System.out.println(dan + "*" + num + "=" + (dan*num) + " ");
			}
			break;
		case 7:
			for(int num=1; num<10; num++)
			{
				System.out.println(dan + "*" + num + "=" + (dan*num) + " ");
			}
			break;
		case 8:
			for(int num=1; num<10; num++)
			{
				System.out.println(dan + "*" + num + "=" + (dan*num) + " ");
			}
			break;
		case 9:
			for(int num=1; num<10; num++)
			{
				System.out.println(dan + "*" + num + "=" + (dan*num) + " ");
			}
			break;
		default :
			System.out.println("�Է¿���");
			
		}
		scanner.close();

	}

}
