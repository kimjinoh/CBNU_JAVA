
abstract class Abstract_Star {
	abstract void attack();
}
